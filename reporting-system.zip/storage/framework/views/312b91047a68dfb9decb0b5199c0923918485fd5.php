<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('plugins/dataTable/dataTables.bootstrap.min.css')); ?>" media="screen" title="no title" charset="utf-8">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>
      Laporan
    </h1>
  </section>

  <!-- Main content -->
  <section class="content">
    <div class="row">
      <div class="col-xs-12">
          <!-- general form elements -->
          <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">Laporan Barang</h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
              <div class="box-body">
                <?php echo $__env->make('includes.message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <div class="table-responsive">
                  <table id="product-report" class="table table-bordered table-striped">
                    <thead>
                      <tr>
                        <th>Nomor</th>
                        <th>Nama Produk</th>
                        <th>Jumlah Stok</th>
                        <th>Harga Jual</th>
                        <th>#</th>
                      </tr>
                    </thead>

                    <tbody>
                      <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                          <td>
                              <?php echo e($loop->iteration); ?>

                          </td>
                          <td>
                            <?php echo e($value->name); ?>

                          </td>
                          <td>
                            <?php echo e(number_format($value->stock)); ?>

                          </td>
                          <td>
                            <?php echo e(number_format($value->selling_price)); ?>

                          </td>
                          <td><a href="<?php echo e(route('product.delete', ['id' => $value->id])); ?>">Hapus</a>| <a href="<?php echo e(route('product.edit',['id' => $value->id])); ?>">Edit</a></td>
                        </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                  </table>

                </div>
              </div>
              <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
    </div>
  </section>
  <!-- /.content -->
</div>
<!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>


<?php $__env->startSection('javascript'); ?>
  <!-- DataTables -->
<script src="<?php echo e(asset('plugins/dataTable/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/dataTable/dataTables.bootstrap.min.js')); ?>"></script>

<script type="text/javascript">
$(function(){
  $('#product-report').DataTable();
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>