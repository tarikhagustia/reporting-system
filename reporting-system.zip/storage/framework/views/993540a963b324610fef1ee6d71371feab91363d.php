<?php $__env->startSection('content'); ?>


<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>
      Buat produk baru
    </h1>
  </section>

  <!-- Main content -->
  <section class="content">
    <div class="row">
      <div class="col-xs-12">
          <!-- general form elements -->
          <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">Buat Produk Baru</h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
            <?php echo $__env->make('includes.message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <form role="form" method="post" action="<?php echo e(route('product.edit.post', ['id' => $product->id])); ?>">
              <?php echo e(csrf_field()); ?>

              <div class="box-body">
                <div class="form-group <?php if($errors->has('sku')): ?> has-error <?php endif; ?>">
                  <label for="exampleInputEmail1">SKU</label>
                  <input class="form-control" id="sku" name="sku" placeholder="Nomor SKU" type="text" value="<?php echo e($product->sku); ?>">
                  <p class="help-block">
                    <?php echo e($errors->first('sku')); ?>

                  </p>
                </div>
                <div class="form-group <?php if($errors->has('name')): ?> has-error <?php endif; ?>">
                  <label for="name">Nama Produk</label>
                  <input class="form-control" id="name" name="name" placeholder="Nama Produk" type="text" value="<?php echo e($product->name); ?>">
                  <p class="help-block">
                    <?php echo e($errors->first('name')); ?>

                  </p>
                </div>
                <div class="form-group <?php if($errors->has('category_id')): ?> has-error <?php endif; ?>">
                  <label for="name">Kategori</label>
                  <select class="form-control" name="category_id">
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($row->id); ?>"><?php echo e($row->category_name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                  <p class="help-block">
                    <?php echo e($errors->first('category_id')); ?>

                  </p>
                </div>
                <div class="form-group <?php if($errors->has('purchase_price')): ?> has-error <?php endif; ?>">
                  <label for="purchase_price">Harga beli</label>
                  <input class="form-control" id="purchase_price" name="purchase_price" placeholder="Harga Beli" type="text" value="<?php echo e($product->selling_price); ?>">
                  <p class="help-block">
                    <?php echo e($errors->first('purchase_price')); ?>

                  </p>
                </div>
                <div class="form-group <?php if($errors->has('selling_price')): ?> has-error <?php endif; ?>">
                  <label for="selling_price">Harga Jual</label>
                  <input class="form-control" id="selling_price" name="selling_price" placeholder="Harga jual" type="text" value="<?php echo e($product->purchase_price); ?>">
                  <p class="help-block">
                    <?php echo e($errors->first('selling_price')); ?>

                  </p>
                </div>
                <div class="form-group <?php if($errors->has('stock')): ?> has-error <?php endif; ?>">
                  <label for="stock">Stok</label>
                  <input class="form-control" id="stock" name="stock" placeholder="Stok awal" type="text" value="<?php echo e($product->stock); ?>">
                  <p class="help-block">
                    <?php echo e($errors->first('stock')); ?>

                  </p>
                </div>
              </div>
              <!-- /.box-body -->

              <div class="box-footer">
                <button type="submit" class="btn btn-primary">Submit</button>
              </div>
            </form>
          </div>
          <!-- /.box -->
        </div>
    </div>
  </section>
  <!-- /.content -->
</div>
<!-- /.content-wrapper -->


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>